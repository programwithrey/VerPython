from tkinter import *
import os

main = Tk()
main.geometry("600x560")
main.title("VerPython Beta")


def command_text():
	com1 = "env"
	com2 = "more"
	com3 = "edit"
	com4 = "help"
	com5 = "web"



def cre_fol():
	path = "T:\\python\\test"
	os.chdir(path)
	new = "env"
	new2 = ".vscode"
	new3 = ".sublime"
	new4 = ".vim"
	new5 = ".atom"
	new6 = ".notepad++"
	new7 = ".leo"
	new8 = ".nano"
	new9 = ".jedit"
	new10 = ".pycharm"
	os.makedirs(new)
	os.makedirs(new2)
	os.makedirs(new3)
	os.makedirs(new4)
	os.makedirs(new5)
	os.makedirs(new6)
	os.makedirs(new7)
	os.makedirs(new8)
	os.makedirs(new9)
	os.makedirs(new10)

def help():
	help_1 = "help"
	help_2 = "Contact"
	help_web = "http://www.verpython.org/help"	


def download_app():
	web = "http://www.verpython.org/download_app"
	filetype = ".exe"
	installer = ""



box = StringVar()

lbl = Label(main, text="VerPython Beta",font=('Calibri',12))
lbl.pack()

trash = Label(main, text="")
trash.pack()

lbl2 = Label(main, text="Choose a name for the enviroment (env)")
lbl2.pack()

trash = Label(main, text="")
trash.pack()

en = Entry(main, textvariable = box)
en.pack()

trash = Label(main, text="")
trash.pack()

btn = Button(main, text="Create", command = cre_fol)
btn.pack()

trash = Label(main, text="")
trash.pack()





main.mainloop()